EverythingEbooks - Offline Ebook Reader & Writing App
=====================================================

SETUP (one-time)
----------------
1. Install Node.js from https://nodejs.org
2. Open Terminal (Mac) or Command Prompt (Windows)
3. Run: npm install -g http-server

QUICK START
-----------
1. Download the zip from GitHub Releases
2. Unzip the file
3. Open Terminal (Mac) or Command Prompt (Windows)
4. cd to the EverythingEbooks folder
5. Run: http-server -p 3000
6. Open browser to http://localhost:3000
7. Press Ctrl+C to stop the server

MORE INFO
---------
Online version: https://everythingebooks.org
