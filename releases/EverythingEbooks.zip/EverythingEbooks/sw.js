// Auto-generated at build time - do not edit manually
// Version: 0214440
// Total precached files: 165
const CACHE_VERSION = '0214440';
const CACHE_NAME = `everythingebooks-${CACHE_VERSION}`;

const PRECACHE_URLS = [
  "/404.html",
  "/_next/static/6zRonvMpfigr9I4coQY-K/_buildManifest.js",
  "/_next/static/6zRonvMpfigr9I4coQY-K/_ssgManifest.js",
  "/_next/static/chunks/09c3fab0-4a24634d5d675fe8.js",
  "/_next/static/chunks/0e4210d9-378cc6e0f6867e7c.js",
  "/_next/static/chunks/10.d6249b4c2a8efe21.js",
  "/_next/static/chunks/1120.679dadd42a4b254a.js",
  "/_next/static/chunks/120.f9b224eecbe21536.js",
  "/_next/static/chunks/1432.b8bbd9a2f4204d82.js",
  "/_next/static/chunks/1901-ac84f1c1bd2d1086.js",
  "/_next/static/chunks/2189.0429a6bd2f7a4901.js",
  "/_next/static/chunks/2200.372fe7147019ab35.js",
  "/_next/static/chunks/24775801-c57ecbeeb9ec0681.js",
  "/_next/static/chunks/2480-052ecd13a245dda8.js",
  "/_next/static/chunks/2795-87c2a87cfd812a27.js",
  "/_next/static/chunks/2896.033167f77d48e828.js",
  "/_next/static/chunks/3193.8743d474ae1e3a09.js",
  "/_next/static/chunks/3284.66de5507a377896c.js",
  "/_next/static/chunks/3352.5bc313c8e0d7ccb0.js",
  "/_next/static/chunks/3453-84e34c309a2c3cb1.js",
  "/_next/static/chunks/3562-f56cebfc54428eac.js",
  "/_next/static/chunks/357670bc-77db6f51cb11f337.js",
  "/_next/static/chunks/3745-130436b6f0fa3e10.js",
  "/_next/static/chunks/37a3b1e7-5e92728dbb332ebe.js",
  "/_next/static/chunks/397598c0-94884eeac8b39287.js",
  "/_next/static/chunks/3a974e69-2bedefef3a3c495c.js",
  "/_next/static/chunks/3b72e6b6-9786f6598c7a79ee.js",
  "/_next/static/chunks/3be0a085-43f1b8733f8e3a6a.js",
  "/_next/static/chunks/40f260ba-4352a8d53d7b11bf.js",
  "/_next/static/chunks/42873fbe-88bce9e8c98b3286.js",
  "/_next/static/chunks/4294-95ed4b52721687a3.js",
  "/_next/static/chunks/457-bf83bf814841258c.js",
  "/_next/static/chunks/5080.14ea5c12834fd002.js",
  "/_next/static/chunks/5280.4c3d01fa4b57d652.js",
  "/_next/static/chunks/5350-8587f089f62e631e.js",
  "/_next/static/chunks/5739.3e24d5756f65e463.js",
  "/_next/static/chunks/58d9be02-7cd1ead07a7ab27f.js",
  "/_next/static/chunks/5935.e047599ecc6da458.js",
  "/_next/static/chunks/6040.fb90006bbf1a59cc.js",
  "/_next/static/chunks/6135.e7840aaca0c04430.js",
  "/_next/static/chunks/6172f554-0a9eddccf503e783.js",
  "/_next/static/chunks/61d92813-e1b94f66708570b2.js",
  "/_next/static/chunks/63acdcb2-ccc40c563dfb535f.js",
  "/_next/static/chunks/6550.e1c5b8065f464fb1.js",
  "/_next/static/chunks/681.10642bf46c9b4d43.js",
  "/_next/static/chunks/6853.f1aaffddba19ff16.js",
  "/_next/static/chunks/6921.f2b91c31eea4449a.js",
  "/_next/static/chunks/6937-20d543fd9e593a3a.js",
  "/_next/static/chunks/6a5c78bf-fe03a4367626e935.js",
  "/_next/static/chunks/7070-0999693d32390e10.js",
  "/_next/static/chunks/7182.a4964100048a5706.js",
  "/_next/static/chunks/71eaaf02-7741f93da0ee1922.js",
  "/_next/static/chunks/7216.396cab1753b8b0fb.js",
  "/_next/static/chunks/7400-717448b53caf3965.js",
  "/_next/static/chunks/750ca729-4f45ae889d067d85.js",
  "/_next/static/chunks/7776-5e25d41a60f1f829.js",
  "/_next/static/chunks/796.60f768d30211edb0.js",
  "/_next/static/chunks/7977-3607b6fb4d732a15.js",
  "/_next/static/chunks/7a2846ee-450a9c379e3ef8e4.js",
  "/_next/static/chunks/8245-769b9b4796acee6b.js",
  "/_next/static/chunks/8246.a8c0e716e19d383a.js",
  "/_next/static/chunks/8383d99d-6580e093bdfd3288.js",
  "/_next/static/chunks/89aeb8c0-06804357b5696f87.js",
  "/_next/static/chunks/8bb0ad1d-e2bf857af2018807.js",
  "/_next/static/chunks/9023.60d2762b705dbcd3.js",
  "/_next/static/chunks/903.24e1afa92a4ffb4d.js",
  "/_next/static/chunks/9098-697e255216c1a6be.js",
  "/_next/static/chunks/9302.f2b91c31eea4449a.js",
  "/_next/static/chunks/9810.a35078e7d8e51ffb.js",
  "/_next/static/chunks/9b402015-db6f729147248dcb.js",
  "/_next/static/chunks/a3eb9ec9-d46c2f4ac7188a92.js",
  "/_next/static/chunks/ab6be8bd-8c74f4bd8c021c88.js",
  "/_next/static/chunks/app/_not-found/page-457564f7f57a06a5.js",
  "/_next/static/chunks/app/authors/layout-686434c1fb8473c8.js",
  "/_next/static/chunks/app/authors/page-0aac2ed76c024818.js",
  "/_next/static/chunks/app/error-44f9f05a44245f7c.js",
  "/_next/static/chunks/app/layout-55703b902c5d0b91.js",
  "/_next/static/chunks/app/library/layout-686434c1fb8473c8.js",
  "/_next/static/chunks/app/library/page-ec4b1a75b8bbc82d.js",
  "/_next/static/chunks/app/page-686434c1fb8473c8.js",
  "/_next/static/chunks/app/reader/page-8f9f8204e07fe184.js",
  "/_next/static/chunks/b2d1c282-cea74abc02efe458.js",
  "/_next/static/chunks/b9c98e3c-b83126947abc7329.js",
  "/_next/static/chunks/c385050f-6d702cecd306d230.js",
  "/_next/static/chunks/c5539990-7c4e34786735d1ce.js",
  "/_next/static/chunks/c7195e9e-caa51f872bf31318.js",
  "/_next/static/chunks/ce940df3-252967321b4dc870.js",
  "/_next/static/chunks/d9ae0e5e-1471f6e308bcd84c.js",
  "/_next/static/chunks/e6a3d702-8c16bdfcf14ebb28.js",
  "/_next/static/chunks/ea2626f0-bfa89eefbf2cbacd.js",
  "/_next/static/chunks/f2bc69ba-3cd719ae29e4abb4.js",
  "/_next/static/chunks/framework-ded4c71141622a87.js",
  "/_next/static/chunks/main-app-9497fe4816b3029f.js",
  "/_next/static/chunks/main-ee348a0734ea5da9.js",
  "/_next/static/chunks/pages/_app-f87ef31dd2826cde.js",
  "/_next/static/chunks/pages/_error-d99c6c53efe9b3bd.js",
  "/_next/static/chunks/pages/reader/[ids]-c7c710fefea39793.js",
  "/_next/static/chunks/polyfills-42372ed130431b0a.js",
  "/_next/static/chunks/webpack-5f3b3dacb297409c.js",
  "/_next/static/css/41a2868416b87847.css",
  "/_next/static/css/93cdcce7ecd431a7.css",
  "/authors.html",
  "/authors.txt",
  "/favicon.ico",
  "/file.svg",
  "/fonts/EBGaramond-Bold.ttf",
  "/fonts/EBGaramond-Regular.ttf",
  "/globe.svg",
  "/icon.png",
  "/icon_120x120.png",
  "/icon_180x180.png",
  "/icon_512x512.png",
  "/images/concrete-texture.png",
  "/images/leaves-pattern.jpg",
  "/images/moon-sky.jpg",
  "/images/night-sky.jpg",
  "/images/paper-texture.png",
  "/images/parchment-paper.jpg",
  "/images/sand-texture.jpg",
  "/images/scrapbook-texture.jpg",
  "/index.html",
  "/index.txt",
  "/library.html",
  "/library.txt",
  "/privacy.html",
  "/reader/[ids].html",
  "/reader.html",
  "/reader.txt",
  "/sitemap.xml",
  "/terms.html",
  "/tool-prompts/AI Writing Tools/brainstorm.txt",
  "/tool-prompts/AI Writing Tools/chapter_writer.txt",
  "/tool-prompts/AI Writing Tools/outline_writer.txt",
  "/tool-prompts/AI Writing Tools/world_writer.txt",
  "/tool-prompts/Core Editing Tools/copy_editing.txt",
  "/tool-prompts/Core Editing Tools/developmental_editing.txt",
  "/tool-prompts/Core Editing Tools/line_editing_by_chapter.txt",
  "/tool-prompts/Core Editing Tools/narrative_internal_analysis.txt",
  "/tool-prompts/Core Editing Tools/narrative_unresolved_analysis.txt",
  "/tool-prompts/Core Editing Tools/proofreader_plot_consistency.txt",
  "/tool-prompts/Core Editing Tools/proofreader_punctuation.txt",
  "/tool-prompts/Other Editing Tools/adjective_adverb_optimizer.txt",
  "/tool-prompts/Other Editing Tools/character_analyzer.txt",
  "/tool-prompts/Other Editing Tools/conflict_analyzer.txt",
  "/tool-prompts/Other Editing Tools/crowding_leaping_evaluator.txt",
  "/tool-prompts/Other Editing Tools/dangling_modifier_checker.txt",
  "/tool-prompts/Other Editing Tools/drunken.txt",
  "/tool-prompts/Other Editing Tools/foreshadowing_tracker.txt",
  "/tool-prompts/Other Editing Tools/kdp_publishing_prep.txt",
  "/tool-prompts/Other Editing Tools/manuscript_to_characters.txt",
  "/tool-prompts/Other Editing Tools/manuscript_to_outline.txt",
  "/tool-prompts/Other Editing Tools/manuscript_to_world.txt",
  "/tool-prompts/Other Editing Tools/plot_thread_tracker.txt",
  "/tool-prompts/Other Editing Tools/proofreader_spelling.txt",
  "/tool-prompts/Other Editing Tools/rhythm_analyzer.txt",
  "/tool-prompts/Other Editing Tools/surmelian_analysis.txt",
  "/tool-prompts/Other Editing Tools/tense_consistency_checker.txt",
  "/tool-prompts/User Tools/anything_goes.txt",
  "/tool-prompts/User Tools/nlp.txt",
  "/tool-prompts/User Tools/nonfiction_SelfHelp_editing.txt",
  "/tool-prompts/User Tools/nonfiction_creative_editing.txt",
  "/tool-prompts/User Tools/nonfiction_integrity_editing.txt",
  "/tool-prompts/User Tools/nonfiction_sourcing_audit.txt",
  "/tool-prompts/index.json",
  "/window.svg"
];

// Install: pre-cache ALL static assets for full offline support
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Precaching', PRECACHE_URLS.length, 'files for offline use...');
        return Promise.all(
          PRECACHE_URLS.map((url) => {
            return fetch(url)
              .then((response) => {
                if (response.ok) {
                  return cache.put(url, response);
                }
                console.warn('Failed to fetch:', url, response.status);
              })
              .catch((err) => {
                console.warn('Failed to pre-cache:', url, err.message);
              });
          })
        );
      })
      .then(() => {
        console.log('Precaching complete - app ready for offline use');
        return self.skipWaiting();
      })
  );
});

// Activate: clean old caches, take control immediately
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames
            .filter((name) => name.startsWith('everythingebooks-') && name !== CACHE_NAME)
            .map((name) => {
              console.log('Deleting old cache:', name);
              return caches.delete(name);
            })
        );
      })
      .then(() => self.clients.claim())
  );
});

// Fetch: cache-first for everything (safe for static export)
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Only handle same-origin requests
  if (url.origin !== self.location.origin) {
    return;
  }

  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }

  // Never cache the service worker script itself
  if (url.pathname === '/sw.js') {
    return;
  }

  // Cache-first for everything
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;

      const pathname = url.pathname;

      // Handle root URL - serve index.html
      if (pathname === '/' || pathname === '') {
        return caches.match('/index.html').then((indexCached) => {
          if (indexCached) return indexCached;
          return fetch(request);
        });
      }

      // Try .html version for clean URLs (e.g., /library -> /library.html)
      if (!pathname.includes('.') && pathname !== '/') {
        const htmlUrl = pathname + '.html';
        return caches.match(htmlUrl).then((htmlCached) => {
          if (htmlCached) return htmlCached;
          // Fall through to network
          return fetch(request).then((response) => {
            if (response.ok) {
              const clone = response.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
            }
            return response;
          });
        });
      }

      return fetch(request).then((response) => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
        }
        return response;
      });
    })
  );
});
